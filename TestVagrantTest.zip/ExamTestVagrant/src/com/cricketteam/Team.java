package com.cricketteam;

import java.util.Arrays;

public class Team {
	String name;
	int points;
	char [] results;
	
	public Team() {
		
	}
	
	public Team(String name, int points, char[] results) {
		super();
		this.name = name;
		this.points = points;
		this.results = results;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPoints() {
		return points;
	}

	public void setPoints(int points) {
		this.points = points;
	}

	public char[] getResults() {
		return results;
	}

	public void setResults(char[] results) {
		this.results = results;
	}

	@Override
	public String toString() {
		return "Team [name=" + name + ", points=" + points + ", Results=" + Arrays.toString(results) + "]";
	}

}
