package com.cricketteam;

public class InValidInput extends RuntimeException {
	
	public String getMessage() {
		return "Enter a Valid input";
	}

	

}
