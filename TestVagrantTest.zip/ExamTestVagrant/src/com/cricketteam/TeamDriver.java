package com.cricketteam;

import java.util.ArrayList;
import java.util.Scanner;

public class TeamDriver {
	public static ArrayList<Team> getWinLoss(ArrayList<Team> ip,int n,String c){
		ArrayList<Team> filter=new ArrayList<>();
		
		String formation="";
		    int l1=0;
		    while(l1<n){
				
				formation+=c;
				l1++;
		}
		    for(int i1=0; i1<ip.size(); i1++) {
				String a="";
				char [] s=ip.get(i1).getResults();
				
				for(int i3=0; i3<s.length; i3++) {
					
					String s2=String.valueOf(s[i3]);
					a+=s2;
				}
				
				if(a.contains(formation)) {
				filter.add(ip.get(i1));
					
				}
				
			}
			
			return filter;
		
	}

	public static void main(String[] args) {
		
		ArrayList<Team> a=new ArrayList<>();
		Scanner sc=new Scanner(System.in);
		a.add(new Team("GT",20,new char [] {'w','w','l','l','w'}));
		a.add(new Team("LSG",18,new char [] {'w','l','l','w','w'}));
		a.add(new Team("RR",16,new char [] {'w','l','w','l','l'}));
		a.add(new Team("DC",14,new char [] {'w','w','l','w','l'}));
		a.add(new Team("RCB",14,new char [] {'l','w','w','l','l'}));
		a.add(new Team("KKR",12,new char [] {'l','w','w','l','w'}));
		a.add(new Team("PBKS",12,new char [] {'l','w','l','w','l'}));
		a.add(new Team("SRH",12,new char [] {'w','l','l','l','l'}));
		a.add(new Team("CSK",8,new char [] {'l','l','w','l','w'}));
		a.add(new Team("MI",6,new char[] {'l','w','l','w','w'}));
		
		//For two consecutive losses
		System.out.println("For two consecutive losses filtered teams are: ");
		ArrayList<Team>ans=getWinLoss(a,2,"l");
		
		for(Team i1:ans) {
			System.out.println(i1);
			
		}
		
		//For n consecutive losses/wins
		System.out.println("Decide consecutive losses and wins as w or l:  ");
		String b=sc.next().toLowerCase();
		
		System.out.println("Enter nth times consecutives losses or wins: ");
		int c=sc.nextInt();
		if(c>5 || c<1) {
			throw new InValidInput();
		}
	
		System.out.println("The Extracted teams are based on above conditions: ");
		ans=getWinLoss(a,c,b);
		double sum=0;
		for(Team i1:ans) {
			System.out.println(i1);
			sum+=i1.getPoints();
			
		}
		
		System.out.println("The Average points of Extracted teams are: "+sum/ans.size());
		
		// TODO Auto-generated method stub

	}


}
